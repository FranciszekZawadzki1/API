package com.example.demo.controller;

import com.example.demo.entity.Book;
import com.example.demo.service.BookService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/book")
public class BookController {
    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/{id}")
    public Book getById(@PathVariable long id) {
        return bookService.getBookById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable long id) {
        bookService.deleteBookById(id);
    }
    //NOWE WARTOŚCI DO KSIĄŻKI:
    @PostMapping
    public Book addBook(@RequestBody Book book) {
//        Book book = new Book(id, "Latarnik", "Henryk Sienkiewicz", 40, 1880, "GREG", 25);
        return bookService.addBook(book);
    }

    @PutMapping
    public Book updateBook(@RequestBody Book book) {
//        Book BookRequest = new Book(id, "Juliusz Słowacki", "Balladyna", 300, 1834, "Nowa Era", 60);
        return bookService.updateBook(book);
    }
}